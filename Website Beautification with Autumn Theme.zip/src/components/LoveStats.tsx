import { motion } from 'motion/react';
import { useEffect, useState } from 'react';
import { Heart, MapPin, FileText } from 'lucide-react';

export function LoveStats() {
  const [daysTogether, setDaysTogether] = useState(0);
  
  useEffect(() => {
    // 计算从2025年1月某日到现在的天数
    const startDate = new Date('2025-01-01'); // 调整为你们在一起的实际日期
    const calculateDays = () => {
      const now = new Date();
      const diff = now.getTime() - startDate.getTime();
      const days = Math.floor(diff / (1000 * 60 * 60 * 24));
      setDaysTogether(days);
    };
    
    calculateDays();
    // 每分钟更新一次
    const interval = setInterval(calculateDays, 60000);
    
    return () => clearInterval(interval);
  }, []);

  const stats = [
    {
      icon: Heart,
      value: daysTogether,
      label: '在一起',
      unit: '天',
      color: 'from-pink-400 to-rose-400',
      iconColor: 'text-pink-500',
    },
    {
      icon: MapPin,
      value: 12,
      label: '走过的地方',
      unit: '个',
      color: 'from-purple-400 to-pink-400',
      iconColor: 'text-purple-500',
    },
    {
      icon: FileText,
      value: 1280,
      label: '写下的文字',
      unit: '字',
      color: 'from-rose-400 to-pink-400',
      iconColor: 'text-rose-500',
    },
  ];

  return (
    <div className="flex gap-8 justify-center items-center">
      {stats.map((stat, index) => (
        <motion.div
          key={stat.label}
          className="relative"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: index * 0.2 }}
        >
          {/* 玻璃卡片效果 */}
          <div className="relative backdrop-blur-md bg-white/30 rounded-3xl p-8 shadow-xl border border-white/40 min-w-[200px]">
            {/* 渐变光晕 */}
            <div className={`absolute inset-0 bg-gradient-to-br ${stat.color} opacity-10 rounded-3xl`} />
            
            {/* 内容 */}
            <div className="relative z-10 flex flex-col items-center gap-3">
              {/* 图标 */}
              <motion.div
                animate={{
                  scale: [1, 1.1, 1],
                  rotate: [0, 5, -5, 0],
                }}
                transition={{
                  duration: 3,
                  repeat: Infinity,
                  ease: 'easeInOut',
                }}
              >
                <stat.icon className={`w-10 h-10 ${stat.iconColor}`} />
              </motion.div>
              
              {/* 数值 */}
              <div className="flex items-baseline gap-1">
                <motion.span
                  className="font-['Quicksand',sans-serif] text-5xl text-gray-800"
                  key={stat.value}
                  initial={{ scale: 1.2, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ duration: 0.3 }}
                >
                  {stat.value}
                </motion.span>
                <span className="font-['Smiley_Sans',sans-serif] text-xl text-gray-600">
                  {stat.unit}
                </span>
              </div>
              
              {/* 标签 */}
              <span className="font-['Smiley_Sans',sans-serif] text-lg text-gray-700">
                {stat.label}
              </span>
            </div>
          </div>
        </motion.div>
      ))}
    </div>
  );
}
