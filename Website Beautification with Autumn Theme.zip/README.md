
  # Website Beautification with Autumn Theme

  This is a code bundle for Website Beautification with Autumn Theme. The original project is available at https://www.figma.com/design/7WYiD8RPZKTu8d4jCHKFw8/Website-Beautification-with-Autumn-Theme.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  